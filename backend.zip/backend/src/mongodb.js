const mongoose = require("mongoose");

mongoose
  .connect("mongodb://127.0.0.1:27017/cvmate")
  .then(() => {
    console.log("mongoose connected");
  })
  .catch((e) => {
    console.log("failed");
  });

const logInSchema = new mongoose.Schema({
  fname: {
    type: String,
    required: true,
  },
  lname: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
  },
  enroll: {
    type: Number,
    required: true,
  },
  bname: {
    type: String,
    required: true,
  },
  gen: {
    type: String,
    required: true,
  },
  uname: {
    type: String,
    required: true,
  },
  pass: {
    type: String,
    required: true,
  },
});

const logInSchema1 = new mongoose.Schema({
  fname: {
    type: String,
    required: true,
  },
  lname: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
  },
  phone: {
    type: Number,
    required: true,
  },
  bname: {
    type: String,
    required: true,
  },
  gen: {
    type: String,
    required: true,
  },
  uname: {
    type: String,
    required: true,
  },
  pass: {
    type: String,
    required: true,
  },
});

const AddActivitySchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
});

const SpiUpdateSchema = new mongoose.Schema({
  enrollment: {
    type: Number,
    required: true,
  },
  spi: {
    type: Number,
  },
  imageurl: {
    type: String,
    required: true,
  },
});

const experience = new mongoose.Schema({
  enrollment: {
    type: Number,
    required: true,
  },
  title: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
  duration: {
    type: String,
    required: true,
  },
  certificateurl: {
    type: String,
    required: true,
  },
});

const projectSchema = new mongoose.Schema({
  enrollment: {
    type: Number,
    required: true,
  },
  title: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
  projectdemolink: {
    type: String,
    required: true,
  },
  projectcodelink: {
    type: String,
    required: true,
  },
});

const achievementSchema = new mongoose.Schema({
  enrollment: {
    type: Number,
    required: true,
  },
  title: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
  link: {
    type: String,
    required: true,
  },
});

const FacultyData = new mongoose.model("FacultyDatas", logInSchema1);
const StudentData = new mongoose.model("StudentDatas", logInSchema);
const Project = new mongoose.model("projects", projectSchema);
// const SendApprovalReq= new mongoose.model('SendApprovalReq',AddActivitySchema)
// const addexperience=new mongoose.model('addexperience',experience)
// const SpiUpdate=new mongoose.model('SpiUpdate',SpiUpdateSchema)
// const achievement=new mongoose.model('achievement',achievementSchema)

// module.exports=FacultyData
// module.exports=StudentData
// module.exports=SendApprovalReq
// module.exports=addexperience
// module.exports=SpiUpdate
// module.exports=project
// module.exports=achievement
module.exports = {
  studentmodule: () => StudentData,
  facultymodule: () => FacultyData,
  projectmodule: () => Project,
};
