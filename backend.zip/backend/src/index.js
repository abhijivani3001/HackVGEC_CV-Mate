const express = require("express");
const app = express();
const path = require("path");
const hbs = require("hbs");
const { studentmodule, facultymodule, projectmodule } = require("./mongodb");
const cors = require("cors");
const bodyParser = require('body-parser')

// var {StudentData} = require("./mongodb");
// var {FacultyData} = require("./mongodb");
// var {SendApprovalReq}=require("./mongodb");

app.use(express.json());
app.use(cors());
app.use(bodyParser.json());
app.set("view engine", "hbs");
const templatePath = path.join(__dirname, "../templates");
app.set("views", templatePath);
app.use(express.urlencoded({ extended: false }));

app.get("/", (req, res) => {
  res.render("../CVMate/page/mainhome.hbs");
});

app.post("/doneaddproject", async (req, res) => {
  const data = {
    enrollment: "37",
    title: req.body.title,
    description: req.body.description,
    projectdemolink: req.body.projectdemolink,
    projectcodelink: req.body.projectcodelink,
  };
  await projectmodule().insertMany([data]);
});

app.get("/getproject", async(req, res) => {
    const response = await projectmodule().find({});
    res.json(response)
})

app.get("/home", async (req, res) => {
  res.redirect("http://localhost:3000");
});

app.get("/signupS", (req, res) => {
  res.render("signupS");
});

// app.get("/signupF",(req,res)=>{
//     res.render("signupF")
// })

app.get("/loginS", (req, res) => {
  // res.render("../templates/loginS")
  res.render("loginS");
});

app.get("/loginF", (req, res) => {
  res.render("loginF");
});

app.post("/addactivity", async (req, res) => {
  const data = {
    title: req.body.title,
    description: req.body.description,
  };
  await collection.insertMany([data]);
  res.redirect("home");
});

app.post("/signupS", async (req, res) => {
  const data = {
    fname: req.body.fname,
    lname: req.body.lname,
    email: req.body.email,
    enroll: req.body.enroll,
    bname: req.body.bname,
    gen: req.body.gen,
    uname: req.body.uname,
    pass: req.body.pass,
  };

  await studentmodule().insertMany([data]);
  res.redirect("home");
});

app.post("/loginS", async (req, res) => {
  try {
    const check = await studentmodule().findOne({ uname: req.body.uname });

    if (check.pass === req.body.pass) {
      res.redirect("home");
    } else {
      res.send("Wrong password");
    }
  } catch {
    res.send("Wrong Details");
  }
});

app.post("/loginF", async (req, res) => {
  try {
    const check = await facultymodule().findOne({ uname: req.body.uname });

    if (check.pass === req.body.pass) res.render("home");
    else {
      res.send("Wrong password");
    }
  } catch {
    res.send("Wrong Details");
  }
});

app.listen(5000, () => console.log("listened port 5000"));
